const success = document.querySelector('.validator-success');
const error = document.querySelector('.validator-error');
const internal = document.querySelector('.validator-internal');

const typeTextArea = document.querySelector('#ptd-type');
const valueTextArea = document.querySelector('#ptd-value');

function handleValidateClick() {
    const type = typeTextArea.value;
    const value = valueTextArea.value;
    
    if (type.length === 0 || value.length === 0) {
        showInternal();
        return;
    } 
    try {
        const parsedValue = JSON.parse(value);
        const parsedTypeLib = JSON.parse(type);
        const typeName = Object.keys(parsedTypeLib)[0]; // get a name of the first type from type lib
        if(verify(parsedValue, typeName, parsedTypeLib)) {
            showSuccess();
        } else {
            showError();
        }
    } catch {
        showInternal();
    }
}

function showInternal() {
    error.style.display = 'none';
    success.style.display = 'none';
    internal.classList.add('fadeIn');
    internal.style.display = 'block';   
}

function showError() {
    internal.style.display = 'none';
    success.style.display = 'none';   
    error.classList.add('fadeIn');
    error.style.display = 'block';
}

function showSuccess() {
    error.style.display = 'none';
    internal.style.display = 'none';   
    success.classList.add('fadeIn');
    success.style.display = 'block';
}
