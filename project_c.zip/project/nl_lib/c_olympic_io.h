/*  
 *  (c) Atinea Sp. z o. o.
 *  Stamp: JJB 2018-06-11
*/

#pragma once

#include <stdbool.h>
#include "c_rt_lib.h"

#define MAX_LINE_LENGTH 2000000

ImmT c_olympic_io0print(ImmT str);
ImmT c_olympic_io0readln();
INT c_olympic_io0read_int();
ImmT c_olympic_io0read_char();
