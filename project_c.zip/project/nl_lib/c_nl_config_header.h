 /*  
 *  (c) Atinea Sp. z o. o.
 *  Stamp: PLE 2016-06-17
*/

#pragma once
