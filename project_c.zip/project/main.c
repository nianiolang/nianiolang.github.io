#include <stdio.h>
#include "nl_out/nianio.h"
#include "nl_lib/c_rt_lib.h"

int main() {
    c_rt_lib0init();

    ImmT state = NULL;
    ImmT cmd = NULL;
    ImmT extcmds = NULL;
    ImmT print_text = NULL;

    c_rt_lib0move(&state, nianio0initial_state());

    c_rt_lib0move(&cmd, c_rt_lib0ov_mk_arg(c_rt_lib0string_new("inc"), c_rt_lib0int_new(1)));
    c_rt_lib0move(&extcmds, nianio0nianio(&state, cmd));
    c_rt_lib0move(&extcmds, nianio0nianio(&state, cmd));
    c_rt_lib0move(&extcmds, nianio0nianio(&state, cmd));

    c_rt_lib0move(&cmd, c_rt_lib0ov_mk_none(c_rt_lib0string_new("print")));
    c_rt_lib0move(&extcmds, nianio0nianio(&state, cmd));

    print_text = c_rt_lib0string_new("print_text");
    for (int i = 0; i < c_rt_lib0array_len(extcmds); i++) {
        ImmT extcmd = NULL;
        c_rt_lib0move(&extcmd, c_rt_lib0array_get(extcmds, i));
        if (c_rt_lib0ov_is(extcmd, print_text)) {
            ImmT as_print_text = NULL;
            c_rt_lib0move(&as_print_text, c_rt_lib0ov_as(extcmd, print_text));
            printf("%lld\n", getIntFromImm(as_print_text));
            c_rt_lib0clear(&as_print_text);
        }
        c_rt_lib0clear(&extcmd);
    }   

    c_rt_lib0clear(&print_text);
    c_rt_lib0clear(&extcmds);
    c_rt_lib0clear(&state);
    c_rt_lib0clear(&cmd);

    return 0;
}

